// Persistent nightly guest rotation and least-seen friendship episodes.
const freshFriendScenes=[
[0,4,'借来的龟壳','King Man找龟壳找到桌边，Paody赶紧把西兰花从壳上拿下来。两位朋友约好：先吃点心，玩具等会儿再借。'],
[1,25,'给小牛留条路','Babii骑着小牛来到门口，Vimmy晃着大耳朵替她指路。两人把椅子挪开一点，给小牛留出宽宽的过道。'],
[2,5,'二十泰铢的合唱','PermPoon数着20泰铢，Polcasan把自己的甜点分了一半。两人轮流介绍《this is your boy》和《i am polcasan》，小勺敲得桌面轻轻响。'],
[3,23,'窗边的星星','Lunar说着「lunar 马辽」跑到窗边，Mr. Saturnworld把星星形状的餐垫推过去。两人给窗外经过的云起名字，差点忘了喝奶茶。'],
[6,8,'先把作业收起来','Tomafox举着红书要告状，Avocean先把作业本合好。小狐狸说有人抄作业，Avocean认真听完，才把一小块蛋糕递过去。'],
[7,22,'甜点伴奏','Jaidee吃到开心就跳起舞，Muvmuv给她唱了一小段。跳到最后，两个人一起向端着甜点的你鞠了个躬。'],
[9,19,'最后一小口','Rexxa盯着最后一块面包，Yuzu Mumu把它分成两份。Rexxa连掉在盘边的小面包屑也认真收好了。'],
[10,30,'菜单后面的声音','Neona躲在菜单后面学「叽叽叽」，Look Khunnoo立刻从另一边探出头：「咔！」两个人一起笑得菜单都拿不稳。'],
[11,27,'慢慢挑，不着急','Metaa把零食摆成一排，让Samruay慢慢选。Samruay的「谢——谢」还没说完，Metaa已经给其他朋友也摆好了小盘子。'],
[12,28,'一局游戏的时间','Nong Nooong和NilkNhake约好轮流尝新口味。一个端稳杯子，一个把餐巾铺好，输赢先放一边，甜点一人一半。'],
[13,33,'给哥哥们的应援','Domiia和Flarey用小叉子排出JASPER的字样。摆到一半发现叉子不够，两人笑着改画了一颗大大的星星。'],
[14,18,'请叫名字','Ceri刚说起奶奶姐姐们起的蛋类外号，Wesley就认真挺起胸：「叫我Wesley！」Ceri点点头，把写着名字的小纸牌摆在盘子前。'],
[15,21,'星星旁边的小空位','Jummo和Tingting把甜点放在桌子中间。两人给晚到的朋友留下一个空位，还特意把最漂亮的一块转向那边。'],
[16,31,'两种语言的谢谢','Renjin捧着餐盘轻轻欠身：「多谢款待。」Guinzly笑着回应：“Thank you, my friend!” 两人碰了碰奶茶杯，给这场下午茶行了个小礼。'],
[17,20,'滚到桌下的餐巾','Momo的餐巾掉到了桌下，PonPon帮忙捡起来，又换了一张干净的。两人重新坐好，认真商量先吃面包还是蛋糕卷。'],
[24,29,'给姐姐也留一份','Any把榴莲奶昔分给Smyle，Smyle先替姐姐Neona留好一杯。Any笑着又拿出一根吸管，等姐姐来一起尝。'],
[26,32,'摆好朋友们的盘子','Jewel和Lykyou一起数桌上的餐盘。数到Any的位置时，两个人各放下一把小叉子，发现放重了，又笑着把多的那把留给下一位朋友。']
];
freshFriendScenes.forEach(([a,b,title,line],i)=>companionScenes.push({id:'fresh-friends-'+i,members:[a,b],title,lines:[line]}));
let friendRotation={night:playState.shift,used:[],counts:{},recent:[]};try{Object.assign(friendRotation,JSON.parse(localStorage.getItem('gemm-friend-rotation')||'{}'))}catch{}
function saveFriendRotation(){try{localStorage.setItem('gemm-friend-rotation',JSON.stringify(friendRotation))}catch{}}
function resetFriendNight(){if(friendRotation.night!==playState.shift){friendRotation.night=playState.shift;friendRotation.used=[]}}
const dialogueBeforeRotation=setVisitDialogue;
setVisitDialogue=function(g){dialogueBeforeRotation(g);let choices=companionScenes.filter(p=>p.members.includes(g.id)).flatMap(p=>p.lines.map((_,part)=>({id:p.id,part,key:p.id+':'+part})));let unseen=choices.filter(c=>!growth.pairStories.some(s=>s.id===c.id&&s.part===c.part));let pool=unseen.length?unseen:choices.filter(c=>!friendRotation.recent.includes(c.id));if(!pool.length)pool=choices;if(!pool.length)return;let minimum=Math.min(...pool.map(c=>friendRotation.counts[c.key]||0));pool=pool.filter(c=>(friendRotation.counts[c.key]||0)===minimum);g.companion=pool[Math.floor(Math.random()*pool.length)];g.companionRecorded=false;g.rotationRecorded=false};
// Replace legacy familiar-guest weighting so it cannot override the nightly draw.
add=function(){resetFriendNight();let pool=names.map((_,i)=>i).filter(i=>!friendRotation.used.includes(i));if(!pool.length){paused=true;toast('今晚所有朋友都来过啦，休息一下再开门吧。');return}let id=pool[Math.floor(Math.random()*pool.length)];friendRotation.used.push(id);saveFriendRotation();let g={id,order:Math.floor(Math.random()*4),patience:100};guests.push(g);assignWish(g)};
const renderBeforeRotation=renderGuests;
renderGuests=function(){renderBeforeRotation();let g=guests[0];if(!g||g.rotationRecorded||!g.companion||diningMoment)return;g.rotationRecorded=true;let c=g.companion;friendRotation.counts[c.key||c.id+':'+c.part]=(friendRotation.counts[c.key||c.id+':'+c.part]||0)+1;friendRotation.recent=[...friendRotation.recent,c.id].slice(-8);saveFriendRotation()};
resetFriendNight();guests.forEach(g=>{if(friendRotation.used.includes(g.id)){let pool=names.map((_,i)=>i).filter(i=>!friendRotation.used.includes(i));if(pool.length){g.id=pool[Math.floor(Math.random()*pool.length)];assignWish(g)}}if(!friendRotation.used.includes(g.id))friendRotation.used.push(g.id);setVisitDialogue(g)});saveFriendRotation();renderGuests();
