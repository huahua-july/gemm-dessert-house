board.before(flavorPanel);
function flavorLocked(){return step>0||!!playState.active}
function syncFlavorFirst(){const locked=flavorLocked();flavorPanel.classList.toggle('flavor-locked',locked);flavorPanel.querySelector('small').textContent=locked?`本份口味：${flavorNames[playState.flavor]} · 制作中已固定`:(playState.flavor===null?'① 先选口味，再开始制作 · 符合娃娃愿望额外 +15':`已选${flavorNames[playState.flavor]}味 · 开始制作后固定`);flavorPanel.querySelectorAll('[data-flavor]').forEach(b=>{b.disabled=locked;b.setAttribute('aria-pressed',Number(b.dataset.flavor)===playState.flavor?'true':'false')});const start=board.querySelector('.scene-start');if(start){start.disabled=playState.flavor===null;if(playState.flavor===null)start.textContent='先选择上方口味';}}
const chooseBeforeFirst=chooseFlavor;chooseFlavor=function(i){if(flavorLocked()){toast('这份已经开始制作，口味固定啦。重新制作后可以更换。');return}chooseBeforeFirst(i);syncFlavorFirst();const start=board.querySelector('.scene-start');if(start&&playState.flavor!==null)start.textContent='开始这一步 →'};
const startBeforeFirst=startSkill;startSkill=function(){if(playState.flavor===null){toast('先选择草莓、抹茶或巧克力，再开始制作。');return}startBeforeFirst();syncFlavorFirst()};
const drawBeforeFirst=drawChallenge;drawChallenge=function(){drawBeforeFirst();syncFlavorFirst()};
const resetBeforeFirst=reset;reset=function(){resetBeforeFirst();syncFlavorFirst()};
const selectBeforeFirst=select;select=function(i){selectBeforeFirst(i);syncFlavorFirst()};
renderRecipe();
