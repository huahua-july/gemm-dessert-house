// One row per recipe, five stages per row, all from the same illustration atlas.
const sceneLabels=[['空杯与珍珠材料','加入珍珠','倒入红茶','鲜奶旋入奶茶','兔兔珍珠奶茶完成'],['蛋糕胚与烘焙纸','抹上蓬松奶油','挤上草莓果酱','卷起并切成小卷','草莓奶油蛋糕卷完成'],['烤盘与裱花袋','挤出圆圆的面糊','烘烤粉色饼壳','挤入草莓夹心','兔兔马卡龙完成'],['面团与擀面杖','轻轻揉面','捏出兔兔小熊造型','烤成金黄小面包','兔兔小熊面包出炉']];
function foodPicture(d,s,kind='scene'){return `<span class="food-illustration ${kind}" role="img" aria-label="${sceneLabels[d][s]}" style="--food-x:${s*25}%;--food-y:${d*100/3}%"></span>`}
for(let i=0;i<menu.length;i++)menu[i].icon=foodPicture(i,4,'menu-art');
art=function(){return foodPicture(selected,Math.min(4,step),'large-art')};
const drawWithPicture=drawChallenge;drawChallenge=function(){drawWithPicture();let stage=Math.min(4,step+(playState.active&&selected!==1?1:0));$('food').innerHTML=foodPicture(selected,stage,'large-art');$('food').setAttribute('aria-label',sceneLabels[selected][stage]);};
const renderIllustratedRecipe=renderRecipe;renderRecipe=function(){renderIllustratedRecipe();document.querySelectorAll('#tabs button').forEach((b,i)=>b.setAttribute('aria-label',menu[i].name));};
const skillWithPicture=startSkill;startSkill=function(){skillWithPicture();if(playState.active)$('progress').textContent='正在'+menu[selected].steps[step]+' · '+sceneLabels[selected][Math.min(4,step+(selected!==1?1:0))]};
// Illustrated jam jars and moulds retain their existing controls and scoring.
const drawIllustratedControls=drawChallenge;drawChallenge=function(){drawIllustratedControls();const a=playState.active;if(!a)return;if(a.mode==='jamchoose'){board.querySelectorAll('[data-jam]').forEach((b,i)=>{b.innerHTML=`${foodPicture(1,2,'ingredient-art')}<span>${flavorNames[i]}果酱</span>`;b.classList.add('flavor-art-'+i)})}if(a.mode==='mold'){board.querySelectorAll('[data-mold]').forEach((b,i)=>{b.innerHTML=`${foodPicture(3,i===0?4:2,'ingredient-art')}<small>${['兔兔 · 长耳朵','猫猫 · 尖耳朵','小熊 · 圆耳朵'][i]}</small>`})}};
renderGuests();renderRecipe();
