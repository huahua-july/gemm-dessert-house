// Public X tone references; all Chinese game dialogue and food preferences are original.
const mascotProfiles=[
  {
    "trait": "酷酷爱互动",
    "hello": "今天也帅气登场！给我来份甜点吧。",
    "wait": "我在这里保持帅气，等你做好。",
    "thanks": "不错嘛，这份手艺很酷！",
    "source": "https://x.com/kingman_gmmtv/status/2122288709488030042",
    "note": "近期以装酷、挑战朋友的口吻互动。"
  },
  {
    "trait": "热情呼朋唤友",
    "hello": "大家快来，这家闻起来好香！",
    "wait": "我给你加油呀！",
    "thanks": "好开心，下次还要来！",
    "source": "https://x.com/BABII_GMMTV/status/2122274475102384296",
    "note": "近期热情邀请大家来看活动。"
  },
  {
    "trait": "爱撒娇、爱找朋友玩",
    "hello": "嘟嘟，我来找你玩，也想吃甜甜。",
    "wait": "我会乖乖等一下下。",
    "thanks": "嘤，好吃得想再来一次！",
    "source": "https://x.com/polcasan_GMMTV/status/2122275915317313861",
    "note": "和朋友玩耍时使用亲昵拟声语气。"
  },
  {
    "trait": "快乐小吃货",
    "hello": "早餐吃过啦，不过甜点还有位置！",
    "wait": "我的甜点胃已经准备好了。",
    "thanks": "吃饱饱，今天也要开心！",
    "source": "https://x.com/mrstnwrd_GMMTV/status/2122130121901609422",
    "note": "分享丰盛早餐，也提醒大家吃早餐。"
  },
  {
    "trait": "甜甜打趣",
    "hello": "听说这里有甜蜜诱惑，我来啦。",
    "wait": "这份甜蜜值得等一等。",
    "thanks": "今天的甜蜜，我收下啦。",
    "source": "https://x.com/paody_GMMTV/status/2120004756450287920",
    "note": "近期以俏皮的甜蜜邀请语气互动。"
  },
  {
    "trait": "调皮元气",
    "hello": "喵喵？嘿嘿，是我来玩啦！",
    "wait": "做甜点的时候也要加油喵。",
    "thanks": "好吃！一起蹦蹦跳跳回家吧。",
    "source": "https://x.com/permpoon_GMMTV/status/2121906106469650793",
    "note": "近期用猫叫拟声与朋友互动。"
  },
  {
    "trait": "撒娇求夸、贴心感谢",
    "hello": "小狐狸来补充能量，你有看见我吗？",
    "wait": "忙完也记得休息一下哦。",
    "thanks": "谢谢你！小狐狸能量满格！",
    "source": "https://x.com/tomafox_gmmtv/status/2121969656177279446",
    "note": "感谢支持，也提醒大家让手指休息。"
  },
  {
    "trait": "热情应援",
    "hello": "我来给今天的小店加油！",
    "wait": "加油加油，我在这里。",
    "thanks": "这份甜点值得鼓掌！",
    "source": "https://x.com/jaidee__GMMTV/status/2117628541072257199",
    "note": "近期应援动态作语气参考，资料有限。"
  },
  {
    "trait": "亲昵顾朋友",
    "hello": "来打个招呼，再带一份甜甜。",
    "wait": "等一下没关系，见到你就很开心。",
    "thanks": "谢谢招待，下次再见呀。",
    "source": "https://x.com/avocean_GMMTV/status/2121918055571984509",
    "note": "感谢大家来见面，并约定再次相见。"
  },
  {
    "trait": "傲娇小猫",
    "hello": "喵，今天想做一只酷酷的小猫。",
    "wait": "我才没有偷偷看甜点呢，喵。",
    "thanks": "嗯……很好吃，允许你再夸夸我。",
    "source": "https://x.com/yuzu_mumu_gmmtv/status/2117602685855867120",
    "note": "以小猫口吻俏皮地练习装酷。"
  },
  {
    "trait": "软糯温柔",
    "hello": "见到你真好，想吃一份暖暖的甜点。",
    "wait": "慢慢来，我在这里陪你。",
    "thanks": "你的心意，我好好收到了。",
    "source": "https://x.com/_lookkhunnoo/status/2121519092863500632",
    "note": "近期温柔感谢大家的关心。"
  },
  {
    "trait": "夸张话痨、爱说发财",
    "hello": "开店大吉！甜甜和好运都要满满！",
    "wait": "这么香，发财的胃先动啦！",
    "thanks": "好吃到想大声宣布！",
    "source": "https://x.com/samruay_GMMTV/status/2121498116004421705",
    "note": "近期用夸张感叹与发财祝福打趣。"
  },
  {
    "trait": "活泼爱唱跳",
    "hello": "叮叮叮，我带着小节拍来啦。",
    "wait": "等甜点也可以跟着节拍摇一摇。",
    "thanks": "叮！这份快乐满分！",
    "source": "https://x.com/NONG_NOOONG/status/2120779196419166660",
    "note": "近期分享音乐节拍挑战。"
  },
  {
    "trait": "奶声奶气的小吃货",
    "hello": "零食袋空空，想再吃一点点。",
    "wait": "一点点就好……再多一点点。",
    "thanks": "肚肚和心心都装满啦！",
    "source": "https://x.com/domiia_GMMTV/status/2121492883786346580",
    "note": "近期以童趣拼写谈吃饭和零食；译意仅作参考。"
  },
  {
    "trait": "爱求表扬",
    "hello": "小猫今天表现好不好？想要奖励甜点。",
    "wait": "等做好，你也要夸夸自己哦。",
    "thanks": "你超厉害，小猫也要给你夸夸！",
    "source": "https://x.com/wesley_gmmtv/status/2120147306884587564",
    "note": "近期以小猫口吻求表扬并道谢。"
  },
  {
    "trait": "活泼爱合照",
    "hello": "今天的甜点也想和我合个照吗？",
    "wait": "先想好等会儿的拍照姿势。",
    "thanks": "咔嚓！把好吃的回忆留下来。",
    "source": "https://x.com/jummo__gmmtv/status/2122299493907632314",
    "note": "近期分享自拍并俏皮打趣。"
  },
  {
    "trait": "温暖又俏皮",
    "hello": "猜猜谁来吃甜点啦？是我哦。",
    "wait": "我先收藏这份香香的期待。",
    "thanks": "谢谢你，今晚一定有甜甜的梦。",
    "source": "https://x.com/guinzly__gmmtv/status/2120893399511511350",
    "note": "公开互动含温暖晚安和俏皮提问。"
  },
  {
    "trait": "装酷爱闹",
    "hello": "酷酷登场，甜点也要闪亮！",
    "wait": "我先摆一个帅气的姿势。",
    "thanks": "太棒啦，今天的快乐加满！",
    "source": "https://x.com/momo_gmmtv/status/2119019991630856537",
    "note": "近期用帅气、兴奋的口吻互动。"
  },
  {
    "trait": "轻快打招呼",
    "hello": "Ceri来啦，今天有什么好吃的？",
    "wait": "我在这里给你加油。",
    "thanks": "谢谢，这一口真开心。",
    "source": "https://x.com/ceri__gmmtv/status/2117530636089012643",
    "note": "近期打招呼动态作参考；资料较少。"
  },
  {
    "trait": "酷酷爱热闹",
    "hello": "小恐龙来补充冒险能量！",
    "wait": "下一场冒险前，先等你做好。",
    "thanks": "出发！带着好味道去冒险。",
    "source": "https://x.com/REXXA__gmmtv/status/2117631494328078580",
    "note": "近期以酷酷的表情热情应援；冒险台词为游戏创作。"
  },
  {
    "trait": "调皮明亮爱玩",
    "hello": "耶！今天来玩什么好吃的？",
    "wait": "我保证只偷偷期待一下。",
    "thanks": "谢谢投喂！玩耍能量回来啦。",
    "source": "https://x.com/PONPON_gmmtv/status/2121556221434151023",
    "note": "近期表达玩耍快乐并感谢投喂。"
  },
  {
    "trait": "温暖陪伴",
    "hello": "我带着暖暖的心意来啦。",
    "wait": "不着急，我陪你慢慢做。",
    "thanks": "谢谢你，送你一个暖暖抱抱。",
    "source": "https://x.com/GMMTV/status/2104896486979105043",
    "note": "仅参考官方登场介绍；未核对独立 X 账号，台词为原创。"
  },
  {
    "trait": "热情表达喜欢",
    "hello": "最喜欢和大家一起吃甜甜啦！",
    "wait": "我已经开始期待第一口了！",
    "thanks": "喜欢喜欢，心都要融化啦！",
    "source": "https://x.com/muvmuv_GMMTV/status/2121969806576365692",
    "note": "近期直率表达喜欢与开心。"
  },
  {
    "trait": "热闹又贴心",
    "hello": "Lunar来啦！给小店加点热闹。",
    "wait": "忙完也要照顾好自己哦。",
    "thanks": "谢谢你，回家路上也要开心！",
    "source": "https://x.com/lunar_GMMTV/status/2121900425167397226",
    "note": "活动后感谢大家，也关心返程和天气。"
  },
  {
    "trait": "软软念着朋友",
    "hello": "想念大家的时候，就来这里坐一坐。",
    "wait": "我抱着小小期待等你。",
    "thanks": "这份甜甜，要放进今天的回忆里。",
    "source": "https://x.com/any_GMMTV/status/2122359077900804311",
    "note": "近期以柔软语气表达对大家的想念。"
  },
  {
    "trait": "俏皮邀请",
    "hello": "今天一起加一点甜蜜怎么样？",
    "wait": "香味已经飞过来啦。",
    "thanks": "甜蜜收到！下次一起再来。",
    "source": "https://x.com/vimmy_gmmtv/status/2121470504607551602",
    "note": "近期俏皮邀请大家到 GEMM HOUSE 吃甜点。"
  },
  {
    "trait": "爱拍照、爱表现",
    "hello": "先摆个漂亮姿势，再开动吧。",
    "wait": "这份甜点等会儿要拍得美美的。",
    "thanks": "好看又好吃，今天闪闪发光！",
    "source": "https://x.com/JewelGMMTV/status/2122199583040458768",
    "note": "近期提到到店拍照、吃东西；台词为原创。"
  },
  {
    "trait": "体贴张罗",
    "hello": "朋友们的份准备好了吗？我也来帮忙。",
    "wait": "你忙，我在这里给大家留位置。",
    "thanks": "谢谢照顾大家，辛苦啦！",
    "source": "https://x.com/metaa_gmmtv/status/2122327889987371123",
    "note": "近期用为朋友安排接送的情景互动。"
  },
  {
    "trait": "活泼又会害羞",
    "hello": "我先跑一小圈，再回来吃甜甜！",
    "wait": "闻到香味，就有一点点害羞。",
    "thanks": "能量补好啦，再去玩一会儿！",
    "source": "https://x.com/NILKNHAKE_/status/2122129087997305108",
    "note": "近期表达想跑玩；另有害羞见面动态。"
  },
  {
    "trait": "好奇话多的小吃货",
    "hello": "我有一个问题：甜点怎么能这么香？",
    "wait": "边等边想，下一口会是什么味道？",
    "thanks": "问题解决啦，答案是好好吃！",
    "source": "https://x.com/smyle_GMMTV/status/2121981627408826559",
    "note": "近期围绕糖糕歌词好奇提问并说好吃。"
  },
  {
    "trait": "俏皮装酷",
    "hello": "酷酷登场！今天也想来点甜的。",
    "wait": "我先酷一下，你继续忙。",
    "thanks": "不错嘛！偷偷给你多一颗心。",
    "source": "https://x.com/neona_GMMTV/status/2122285114835292595",
    "note": "近期以装酷表情和朋友俏皮互动。"
  },
  {
    "trait": "小侠客口吻",
    "hello": "在下游历至此，求一份补充能量的点心。",
    "wait": "劳烦店家，在下静候佳肴。",
    "thanks": "多谢款待，江湖再见！",
    "source": "https://x.com/renjin_gmmtv/status/2120448284355592587",
    "note": "近期以武林人士口吻询问补充能量的食物。"
  },
  {
    "trait": "爽朗运动派",
    "hello": "兄弟，活动完来补充点能量！",
    "wait": "期待值和运动热情一样满格。",
    "thanks": "太开心啦，下次还一起！",
    "source": "https://x.com/_LYKYOU/status/2119820743152427456",
    "note": "近期爽朗邀请大家活动身体。"
  },
  {
    "trait": "热情黏人、会打趣",
    "hello": "拜托拜托，今天想来一份甜甜！",
    "wait": "第一次来的朋友也要一起玩哦。",
    "thanks": "谢谢款待，下次还要来看你！",
    "source": "https://x.com/FLAREY__GMMTV/status/2122268184539713943",
    "note": "近期重复撒娇邀请，也与 Rexxa 打趣。"
  }
];
