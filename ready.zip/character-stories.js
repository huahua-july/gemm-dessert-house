const characterStories=[
  {
    "title": "龟壳去哪儿了",
    "hello": "我的龟壳被朋友拿去玩啦！我先在你这里吃一点。",
    "wait": "吃完再去找他们，把龟壳带回来。",
    "thanks": "找龟壳之前先找到好吃的了！",
    "postcard": "龟壳今天又被借走，不过你留给我的座位还在。等我拿回龟壳，就带你去兜风！",
    "first": "King Man摸了摸背后，空空的。朋友把龟壳拿去玩了，他顺着笑声找来，却先被橱窗里的甜点留住。你递给他一张便签：「先吃饱，再找龟壳。」",
    "second": "朋友抱着龟壳跑回来，King Man故意板起脸，下一秒却把甜点往中间推：「下次借之前先说一声，甜点倒是可以一起吃。」"
  },
  {
    "title": "骑牛来吃下午茶",
    "hello": "哞——我骑着我的牛来啦！可以给它留个位置吗？",
    "wait": "牛在外面乖乖等，我也乖乖等。",
    "thanks": "好吃！下次再骑牛来找你！",
    "postcard": "今天的路是小牛带我走的，今天的甜是你给我的。下次听到哞哞声，就是我来啦！",
    "first": "门外传来一声「哞」。Babii骑着她的牛到了门口，认真替牛也找了个阴凉位置，才踮脚看向菜单。",
    "second": "下起小雨时，Babii先把小牛牵到屋檐下。你把打包袋递给她，她拍拍牛背：「慢慢走，别把这份甜甜颠坏啦。」",
    "gender": "female"
  },
  {
    "title": "给papa和phorphor的打包袋",
    "hello": "san来啦！这一份要带给papa、phorphor尝尝。",
    "wait": "给papa一份，给phorphor一份……san也要一小口。",
    "thanks": "papa和phorphor一定会喜欢！",
    "postcard": "谢谢你把甜点包得好好的。san要带回去给papa、phorphor尝尝，回来再告诉你他们有多喜欢！",
    "first": "san把两张小纸条摊在桌上，一张写papa，一张写phorphor。你刚把甜点端来，他就认真比较哪一块该放进哪个袋子。",
    "second": "san回来时还带着上次的包装丝带：「papa和phorphor都尝过啦！」他小心把丝带收好，又补上一句：「今天也一起打包，好不好？」"
  },
  {
    "title": "火箭补给站",
    "hello": "出发之前，我的甜点补给准备好了吗？",
    "wait": "火箭等一等，我还要吃一口。",
    "thanks": "能量满格！准备出发！",
    "postcard": "谢谢小店长的甜点补给。火箭绕远一点也没关系，这里永远是我想回来停靠的一站。",
    "first": "Mr. Saturnworld把火箭停在想象中的窗边，拿菜单当航行地图，认真标出甜点的位置。",
    "second": "他把最后一口留到出发前才吃：「这样就能把味道记到下一站。」你替他的地图盖了一颗小星星。"
  },
  {
    "title": "西兰花小捣蛋",
    "hello": "Paody带着西兰花来啦！今天又想调皮一下。",
    "wait": "西兰花先乖乖放好，我等甜点。",
    "thanks": "好吃！先把西兰花放下，认真吃这一口。",
    "postcard": "我是特别调皮的Paody，总忍不住拿手里的西兰花敲敲朋友。今天先把小捣蛋收好，写一句认真的谢谢给你，下次还来玩！",
    "first": "Paody抱着西兰花进门，趁朋友看菜单时轻轻敲了一下。对方刚转过头，Paody又赶紧把西兰花藏到身后，一脸「刚刚发生什么了」的小表情。",
    "second": "Tomafox刚开始告状，Paody就把西兰花举起来假装认真研究叶子。你把甜点放在两个人中间，他终于先放下西兰花，和朋友一起吃起来。"
  },
  {
    "title": "20泰铢的零花钱",
    "hello": "我今天的零花钱只有20泰铢，要认真挑哦。",
    "wait": "数一数……只有20泰铢，不能乱花。",
    "thanks": "这一口好值得，我要慢慢吃！",
    "postcard": "我的20泰铢小钱包很薄，今天的快乐却很满。谢谢你让我把每一口都吃得很珍惜！ 也记得给爸爸们的男团JASPER加油哦！",
    "first": "PermPoon把零花钱一枚枚排开，认真宣布：「今天只有20泰铢！」他不是在催你打折，只是想把有限的钱和无限的期待都算清楚。 聊到爸爸们时，PermPoon又兴奋地介绍他们组成的男团JASPER。",
    "second": "你们一起比较份量和口味，他最后选好一份，抱着袋子说：「剩下的快乐不用花钱，我要带去和朋友讲！」"
  },
  {
    "title": "红书后面的小狐狸",
    "hello": "小狐狸来告状啦！先听我说完，再吃甜点。",
    "wait": "甜点包好，我还得赶回课堂呢。",
    "thanks": "太香啦！吃完回去把漏掉的补上。",
    "postcard": "红书里夹了一张甜甜便签。今天偷偷溜来的一小会儿，值得记住；落下的课我也会认真补回来！ 小狐狸还有好多小状要告，下次你也要听我慢慢讲。",
    "first": "Tomafox举起红书，神神秘秘地宣布：「我来告状！」刚说到一半，逃课跑来吃甜点的小秘密却差点先露了馅。",
    "second": "Metaa替Tomafox留好了零食，小狐狸却还忙着告状：「Paody又拿西兰花敲人啦！」你把点单纸往旁边挪开，先让他把话说完。"
  },
  {
    "title": "甜点和足球之间",
    "hello": "奶奶姐姐们叫我荷包蛋，deedee来啦！吃到开心就要跳舞。",
    "wait": "吃完要去球场，我先在心里跳一小段。",
    "thanks": "太好吃啦！deedee要跳舞！",
    "postcard": "好吃到脚尖都忍不住动起来！谢谢你的甜点，deedee跳完这支小舞，就跟daddy去踢足球啦。 荷包蛋deedee也会给爸爸们的JASPER加油，下次跳一段给你看！ 荷包蛋是奶奶姐姐们给我起的外号，好吃的时候我还是会开心地跳舞！",
    "first": "Jaidee一手指着甜点，一手指着门外：「daddy等会儿要送deedee去踢足球！」话刚说完，脚尖已经跟着香味打起拍子。 奶奶姐姐们给deedee起了荷包蛋这个外号，她听见就快乐地抖了抖脚尖，顺便说起爸爸们组成的男团JASPER。",
    "second": "她吃到喜欢的那口，快乐地转了半圈，差点把纸巾当成啦啦队旗。你们约好，下次踢完球再来补充能量。",
    "gender": "female"
  },
  {
    "title": "作业本旁的两份甜点",
    "hello": "好好上学以后再来吃甜甜。Samruay，我帮你拿着这份。",
    "wait": "作业本先收好，Samruay的那份我会照顾。",
    "thanks": "Samruay，慢慢吃，不着急。",
    "postcard": "作业有时候会被朋友借去抄，但给你的谢谢是我自己写的！我会好好上学，也会照顾Samruay一起吃甜点。",
    "first": "Avocean把作业本放好，一看才发现朋友抄作业时连边上的小涂鸦都抄了。Samruay还在慢慢挑口味，他就耐心把菜单移过去：「不急，我陪你选。」",
    "second": "打包时，Avocean先接住Samruay差点滑下来的袋子，又替他把吸管放好。你递来第二份餐具，他认真道谢：「我们会好好吃完，再一起回去。」"
  },
  {
    "title": "小猫与寿司的午后",
    "hello": "喵，先把酷酷的姿势摆好，再看甜点。",
    "wait": "小猫没有偷看，只是在研究菜单，喵。",
    "thanks": "好吃是好吃……再给小猫一点夸夸。",
    "postcard": "今天的小猫本来想一直酷酷的，结果第一口就露馅啦。下次我还会来，记得先说我很帅，再说欢迎光临，喵！",
    "first": "Yuzu Mumu在窗边练习一副酷酷的表情，菜单刚翻到甜点页，耳朵却先动了。",
    "second": "你没有拆穿小猫，只把餐具轻轻递过去。他吃完认真点头：「今天的酷酷计划，明天再继续。」"
  },
  {
    "title": "叽叽叽，咔！",
    "hello": "叽叽叽！Look Khunnoo来啦，咔！",
    "wait": "叽叽叽……好香，咔。",
    "thanks": "叽叽叽！喜欢喜欢，咔！",
    "postcard": "叽叽叽，今天的甜甜收到啦，咔！这张明信片也要亮晶晶的，像你记得我口味时一样。",
    "first": "Look Khunnoo一进门就「叽叽叽」地和你打招呼，句尾又认真补上一个「咔」。你试着跟着说，两个声音在柜台边撞在一起。",
    "second": "你端来甜点，他小声「叽」了一下，又抬头补上响亮的「咔！」你们终于找到只要听见就会笑的暗号。"
  },
  {
    "title": "慢慢来的好运",
    "hello": "我——来——啦……今天，想吃一点甜甜。",
    "wait": "不——急……我在这里，慢慢等。",
    "thanks": "好——吃……这一口，要慢慢记住。",
    "postcard": "这张明信片，我也慢——慢——写。谢谢你愿意等我说完，也谢谢Avocean替我拿好甜点。下次，再一起慢慢吃。",
    "first": "Samruay把「下午好」说得长长的。后面的队伍已经走开，他还没选完，Avocean便在旁边陪着，一页页替他翻菜单。",
    "second": "你没有替他把话接完，而是把甜点放在手边等他说完。「谢——谢。」Samruay笑了，Avocean也把自己的那份往旁边挪了挪。"
  },
  {
    "title": "叮叮，存档成功",
    "hello": "叮叮！今天的小店挑战开始啦。",
    "wait": "等甜点的时候，也要保持节拍。",
    "thanks": "快乐存档成功！下次继续玩！",
    "postcard": "今天的甜点关卡通过啦！把你的名字放进我的快乐存档，下一次见面就从「好朋友」继续。",
    "first": "Nong Nooong把菜单当成游戏选单，点完又给你敲出一小段节拍，像在等待开场音乐。",
    "second": "甜点上桌时，他假装按下手柄的存档键：「这一关不重来，我要留住现在。」"
  },
  {
    "title": "给Any留的一口",
    "hello": "这一份要带给Any吃！我先替她闻一闻。",
    "wait": "Any的那份要包好，我不会偷吃太多。",
    "thanks": "Any一定会喜欢，我现在就带过去！",
    "postcard": "今天的甜点，我给Any也留了一份。谢谢你帮我好好打包，下次我们一起回来，把好吃的故事讲给你听！ 也记得给爸爸们的男团JASPER加油哦！",
    "first": "Domiia指着打包盒说：「这份给Any！」他拿起叉子又放下，努力把想尝一口的心情藏在身后。 聊到爸爸们时，Domiia又兴奋地介绍他们组成的男团JASPER。",
    "second": "Any还没到，Domiia先把她的位置留好。你们一起把盒盖贴上小爱心，等她来时再打开。"
  },
  {
    "title": "水煮蛋？请叫我Wesley",
    "hello": "奶奶姐姐们叫我水煮蛋，我会生气！请叫Wesley，也不许叫奇趣蛋。",
    "wait": "我有名字的，叫Wesley就好。",
    "thanks": "叫对名字的甜点，吃起来更开心！",
    "postcard": "要把Wesley写在收件人那里哦！不是水煮蛋（海东），也不是奇趣蛋。你记得我的名字，我就把这束蓝花一样的好心情送给你。 水煮蛋是奶奶姐姐们给我起的外号，可我还是想听你叫Wesley哦！",
    "first": "奶奶姐姐们给Wesley起过水煮蛋这个外号，听到时他还是会鼓起脸：「我叫Wesley！」旁边又有人想说奇趣蛋，他马上认真摇头。你把写着Wesley的点单牌转正，好好叫了他一声。",
    "second": "他本来还在生气，看到餐盒上端端正正的Wesley，脸颊才慢慢放松。「这次写得对。」他把自己的蓝花束往你面前推近了一点。"
  },
  {
    "title": "把星星装进口袋",
    "hello": "今天的甜点，也值得亮一颗星星吧？",
    "wait": "我先找个拍照时最亮的位置。",
    "thanks": "咔嚓！这一口也要收进相册。",
    "postcard": "一颗星星奖励今天的你，一张照片留住今天的我们。下次合照的时候，我还站在小店这边！",
    "first": "Jummo绕着餐盘找角度，认真得像要替一颗星星挑位置。",
    "second": "你替他把盘子转了半圈，Jummo终于拍到满意的一张，却把最喜欢的照片留给了你。"
  },
  {
    "title": "Guinzly and a sweet little nickname",
    "hello": "Grandmas and big sisters call me Marinated Egg!",
    "wait": "Take your time. I will wait right here.",
    "thanks": "Lovely! Thank you, my friend.",
    "postcard": "Grandmas and big sisters gave me the nickname Marinated Egg. This little note is from Guinzly: thank you for saving a cozy seat for me. I will bring my guitar and a gentle tune next time. See you soon!",
    "first": "Grandmas and big sisters gave Guinzly the nickname Marinated Egg. He rests a tiny guitar beside the menu and says, \"You can call me Guinzly, or Marinated Egg! May I have something sweet?\"",
    "second": "Friends talk about the egg nicknames that grandmas and big sisters gave them. Guinzly smiles and says, \"Marinated Egg, reporting for teatime!\" His little guitar stays beside the plate while everyone shares a sweet afternoon."
  },
  {
    "title": "星星球别滚远",
    "hello": "酷酷登场！我的星星球先放这里。",
    "wait": "球别滚远，甜点马上就好啦。",
    "thanks": "太棒啦，吃完再玩一轮！",
    "postcard": "星星球可以滚来滚去，今天的快乐要好好留住。谢谢你替我看住它，也给我留了一份甜点！",
    "first": "Momo把星星球往柜台边一放，球却不肯停，轻轻撞上了餐巾盒。",
    "second": "你用餐垫替球围了一个小窝。他回来取时故意装酷地点头，抱起来的动作却特别小心。"
  },
  {
    "title": "Ceri不是海椒",
    "hello": "奶奶姐姐们给我起的外号是煎蛋！ceri mai chai 海椒，chai bandao.",
    "wait": "Ceri不是海椒哦，再念一遍给你听。",
    "thanks": "ceri mai chai 海椒，chai bandao. 好吃！",
    "postcard": "ceri mai chai 海椒，chai bandao. 记住这个小暗号，下次我一说，你就知道是Ceri来吃甜点啦！ 煎蛋Ceri也要给爸爸们的JASPER加油，暗号可别念错啦！ 煎蛋是奶奶姐姐们起的外号，Ceri也把这个小称呼记在这里。",
    "first": "Ceri认真念起「ceri mai chai 海椒，chai bandao.」你学了两遍，差点又把句尾念反。Ceri一边摇头一边笑，耐心把暗号再说一次。 奶奶姐姐们还给Ceri起了煎蛋这个外号，Ceri把这个称呼和爸爸们的男团JASPER一起介绍给你。",
    "second": "菜单旁多了一张写着暗号的小纸条。Ceri还没走到柜台，你就先念了前半句，这回他终于满意地接上后半句。"
  },
  {
    "title": "什么都想吃的小恐龙",
    "hello": "Rexxa什么都吃！菜单从第一样开始看！",
    "wait": "这一样、那一样……都闻起来很好吃。",
    "thanks": "吃掉吃掉！这一口也喜欢！",
    "postcard": "没有挑食的小恐龙，只有想再来一口的Rexxa！谢谢你把这么多好味道放进小店，我还要继续探索菜单。",
    "first": "Rexxa一路点着菜单，每翻一页就认真点头：「这个也吃。」你把小份试吃排成一行，他把每一口都当成新发现。",
    "second": "朋友问最喜欢哪一样，他想了很久，把所有盘子都往自己这边挪了一点：「每一样都要再确认一次！」"
  },
  {
    "title": "香蕉分一半",
    "hello": "今天有朋友来吗？香蕉也可以一起分。",
    "wait": "我把最好吃的那口先留着。",
    "thanks": "好吃！分给朋友就更开心！",
    "postcard": "香蕉可以掰成两半，快乐也可以。谢谢你让今天的小店又多了一次分享，下次我带朋友一起来！",
    "first": "PonPon抱着香蕉坐下，看到旁边还有空位，便把香蕉掰成两段放好。",
    "second": "朋友姗姗来迟时，那半根还在等着。你们把两只小盘子拼在一起，像一张刚刚好坐满的桌子。"
  },
  {
    "title": "第四片叶子",
    "hello": "四叶草今天会把好运带到这里吗？",
    "wait": "我先替小店找找幸运的方向。",
    "thanks": "找到了，这一口就是好运！",
    "postcard": "四片叶子，一片给今天，一片给明天，一片给朋友，最后一片送给照顾小店的你。",
    "first": "Tingting把四叶草放在窗边，认真观察叶子朝哪边展开。",
    "second": "你问哪片叶子最幸运，他没有选，反而把整株推给你：「一起留着，就不用分了。」"
  },
  {
    "title": "开心就唱出来",
    "hello": "samtuabaht三铢帮的Muvmuv来啦！Lunar、Any也要一起吃甜甜。",
    "wait": "等Lunar和Any到齐，我先轻轻哼一小段。",
    "thanks": "啦啦啦，三铢帮的快乐加满啦！要和Lunar、Any一起分享。",
    "postcard": "今天开心得唱了一路，唱到小店门口又想起这份甜甜。把歌里的一个小爱心写在这里，送给你！ samtuabaht（三铢帮）下次还要一起回来，我负责唱歌，等Lunar和Any一起开动！",
    "first": "Muvmuv给Lunar和Any留好两张椅子，自己先轻轻哼起歌。samtuabaht（三铢帮）的下午茶还没开始，快乐的旋律已经先到了。",
    "second": "Lunar一声「lunar 马辽」刚落，Any就快乐地念起「dulian ban dulian」。Muvmuv唱着歌把两份餐具推过去，samtuabaht（三铢帮）终于到齐，三份甜点也摆成了一个小小的圈。",
    "gender": "female"
  },
  {
    "title": "窗边高高的身影",
    "hello": "lunar 马辽！窗边的位置先留一下，Dew也许会路过。",
    "wait": "这把小叉子，我先替Dew放好。",
    "thanks": "甜甜吃到啦！这一份先帮我写上Dew的名字。",
    "postcard": "lunar 马辽！窗边的位置还留着，小叉子也替Dew摆好了。谢谢你听我聊今天的小事，samtuabaht（三铢帮）的Muvmuv和Any下次也一起回来！",
    "first": "门口有190以上的高个子走过，Lunar总会先抬头看一眼。发现不是Dew，她就低头把预备好的小叉子摆正，继续和朋友们一起看菜单。",
    "second": "你刚提到Dew，Lunar就把窗边那张椅子又擦了一遍。甜点上桌时，她先招呼同属samtuabaht（三铢帮）的Muvmuv和Any坐好，再把另一份餐具放在空位旁边。",
    "gender": "female"
  },
  {
    "title": "给Jewel留的一杯甜甜",
    "hello": "Jewel还没到，我先把她那杯放好。",
    "wait": "等Jewel来了，我们一起尝尝。",
    "thanks": "好开心，想把这份甜甜分享给Jewel！dulian ban dulian！",
    "postcard": "餐桌旁给Jewel留的位置还在，Muvmuv和Lunar的奶昔也准备好了。谢谢你帮我们把下午茶摆好，下一次朋友们再一起来，dulian ban dulian！",
    "first": "Any把旁边的椅子轻轻拉开，又在杯子下面压好一只纸折的小蝴蝶。「Jewel来了就坐这里吧。」说完，她又把给三铢帮朋友们准备的杯子排成一行。",
    "second": "Jewel刚推开门，Any就把已经放好的杯子往旁边挪了一点。Jewel合上红扇，顺手替她扶好快滑下来的纸巾。等Muvmuv和Lunar也来了，Any又多拿出两只奶昔杯。",
    "gender": "female"
  },
  {
    "title": "大耳朵晃呀晃",
    "hello": "Vimmy来啦，大耳朵先听见甜点的香气！",
    "wait": "耳朵乖乖等，马上就可以晃啦。",
    "thanks": "好开心！大耳朵忍不住晃起来啦！",
    "postcard": "今天耳朵晃了好多下，每一下都是一声谢谢。把蜂蜜一样甜的心情装进卡片，送给记得我口味的你！",
    "first": "Vimmy本来坐得端端正正，甜点一上桌，大耳朵便先晃起来。你笑着把餐盘往安全的地方挪了一点。",
    "second": "她努力让耳朵停住，好认真听你介绍新口味。才听到「甜甜的」，耳朵又把开心全部说出来了。",
    "gender": "female"
  },
  {
    "title": "红扇边留着Any的位置",
    "hello": "Any那份先别收，我帮她摆好餐具。",
    "wait": "Any的那份，能不能也摆得漂亮一点？",
    "thanks": "这份真漂亮，想和Any一起拍下来！",
    "postcard": "红扇旁边给Any留了位置，大家的餐具也都摆好了。谢谢你帮朋友们留住这段热闹的下午，下次再一起拍一张合照！",
    "first": "Jewel把红扇放到桌边，替还没到的Any摆好小叉子。看菜单时，她先问了一句朋友们能不能分着尝，再认真挑了几种适合合照的颜色。",
    "second": "Any把奶昔分给朋友们，Jewel就帮忙扶住杯子、腾出餐盘的位置。你把两份甜点放到桌子中间，谁想尝一口都能轻轻够到。",
    "gender": "female"
  },
  {
    "title": "爸爸的黑卡和大家的零食",
    "hello": "Tomafox的那份先留好，其他朋友也一起吃。",
    "wait": "朋友还没坐齐，我先把大家的位置留好。",
    "thanks": "大家一起吃！这一桌都安排好啦。",
    "postcard": "爸爸的黑卡安排好了一桌零食，朋友们的座位也摆好了。Tomafox的那份留在红书旁边，其他朋友来了也都有份。谢谢你帮我们分好，下次还在这里聚一聚！",
    "first": "Metaa举起爸爸的黑卡，把给朋友们的零食一份份分好。给Tomafox的那一袋先放到红书旁边，随后他又认真数了一遍空椅子：「一个朋友都不能落下。」",
    "second": "朋友们陆续赶到，他把每份零食都往外分。等桌上只剩最后一块，才想起自己还没吃；你早替他留下了一小份。"
  },
  {
    "title": "甜甜杯里的颜色",
    "hello": "今天的甜甜杯，会装哪一种颜色呢？",
    "wait": "先看看杯子，再看看你。",
    "thanks": "这杯快乐，可以带回家！",
    "postcard": "杯子空了也没关系，今天的快乐已经收好了。下次带着杯子来，想再装一点你做的甜甜！",
    "first": "NilkNhake把蓝色甜甜杯放到柜台上，转着看每一面的小图案。",
    "second": "你替杯边贴了一颗小星星，他捧起来时又转回来看了一遍，像是怕错过刚刚多出来的回忆。"
  },
  {
    "title": "姐姐说的话要听好",
    "hello": "Smyle来啦！姐姐Neona说先坐好，我会听姐姐的话。",
    "wait": "姐姐Neona说要耐心等，我乖乖坐在这里。",
    "thanks": "好好吃！我要先给姐姐Neona尝一口。",
    "postcard": "姐姐Neona有点调皮，不过姐姐说的话，我都有认真听。谢谢你记得我，也给姐姐留了甜点。下次我还和姐姐一起来！",
    "first": "Neona姐姐让Smyle先找位置坐好，Smyle就乖乖把椅子摆正，连菜单也认真放好。等他抬头，才发现调皮的姐姐偷偷把自己的纸巾折成了一只小帽子。",
    "second": "姐姐Neona故意把两只餐盒调了位置，笑着让Smyle猜哪一份才是自己的。Smyle先听姐姐说完，又认真看了看名字：「我听姐姐的话，也会好好看标签的。」"
  },
  {
    "title": "调皮姐姐的小把戏",
    "hello": "姐姐Neona来啦！Smyle先坐这边，姐姐来看看甜点。",
    "wait": "Smyle乖乖等着，姐姐先想个小把戏。",
    "thanks": "好吃！Smyle，听姐姐的，再分一小口一起尝。",
    "postcard": "我是有点调皮的姐姐Neona，Smyle总会认真听我的话。今天的小把戏先收好，留一份认真的谢谢给你，下次再和Smyle一起回来！",
    "first": "Neona让Smyle乖乖坐好，自己却在菜单后面偷偷做了个小表情。看到Smyle真的一动不动地等着，她先忍不住笑了出来。",
    "second": "调皮的姐姐Neona把两份甜点换了个位置，又悄悄换回来。Smyle认真等姐姐说完，她最后把最好看的那一份推过去：「好啦，这份给你。」"
  },
  {
    "title": "小生借一盏茶",
    "hello": "小生是Dew家的Renjin，闻得甜香，特来叨扰。",
    "wait": "劳烦店家，小生在此静候。",
    "thanks": "多谢款待，此味当记于心。",
    "postcard": "一盏茶，一碟点心，半晌相谈。承蒙店家照拂，小生将今日温暖记于此笺，愿他日重逢，仍有甜香相迎。 Dew家的小生Renjin，改日再来叨扰。",
    "first": "Dew家的小孩Renjin拱手入店，一副古风小生的模样。他先问了声好，才认真看菜单，想挑一份能带回去与Dew分享的点心。",
    "second": "你把打包袋递去，他竟认真用两只手接过：「今日蒙君款待，改日携新故事再来。」你替他把门帘掀起，送小生走入晚霞。"
  },
  {
    "title": "五个哥哥的份",
    "hello": "LYKN家的Lykyou来啦！五个哥哥的份，一个都不能漏。",
    "wait": "五个哥哥的份数好了……Any的那份，放这边。",
    "thanks": "哥哥们的份都齐啦。Any，这块留给你，慢慢吃！",
    "postcard": "五个哥哥的口味不一样，今天的小袋子也排成了五个。谢谢你陪我一份份记好，下一次我带他们一起来！ 五个哥哥的男团LYKN，也要一起加油！ 今天多留了一份给Any，袋口折得特别整齐。她还没来，我就先把旁边的小椅子擦干净了。",
    "first": "Lykyou认真数着五个哥哥，告诉你哥哥们的男团叫LYKN。点单时他又从头数了一遍，生怕带回去的甜点少了一份。",
    "second": "你们把五个包装排成一列，再给他自己的那份留出位置。他终于满意地点头：「这回，一个都没有漏。」 Any进门时，他把自己盘里最完整的一块轻轻推到她面前，又低头检查了一遍哥哥们的袋子。"
  },
  {
    "title": "红宝石的初次见面",
    "hello": "JASPER的弟弟Flarey来啦！今天也想和朋友一起吃甜点。",
    "wait": "Rexxa有吃饱吗？我也想再尝一口。",
    "thanks": "好开心！下次再和朋友一起来。",
    "postcard": "把红宝石一样亮亮的心情留在这里。谢谢你第一次见面就记得我，下次来，我也会记得先和你打招呼！ JASPER的弟弟Flarey也会带着哥哥们的故事回来找你。",
    "first": "Flarey认真介绍自己是JASPER的弟弟，想给哥哥们留好位置。你把菜单递过去，他一边看甜点，一边说起Domiia、PermPoon、Ceri和Jaidee的爸爸们组成的这个男团。",
    "second": "Rexxa已经在看下一页菜单，Flarey笑着提醒他慢一点。你把两份餐具摆好，让这次相遇有了刚刚好的位置。"
  }
];
characterStories.forEach((c,id)=>{Object.assign(mascotProfiles[id],{hello:c.hello,wait:c.wait,thanks:c.thanks})});
function giftMessage(g){let c=characterStories[g.mascot];if(g.mascot===16)return g.stage===0?c.postcard:g.stage===1?'This treat is on me. Thank you for our lovely teatimes!':'This little guitar is for you. Keep a little melody from our friendship.';return g.stage===0?c.postcard:g.stage===1?c.thanks+' 这次换我请你，感谢券要记得用哦。':c.thanks+' 这份'+personalGiftName(g.mascot)+'，留给我们的小回忆。'}
const characterTraits={0:'龟壳总被朋友借走',1:'骑着小牛来做客',2:'给papa、phorphor打包',5:'20泰铢的小钱包',6:'偷偷溜来的小狐狸',7:'爱跳舞的足球小朋友',8:'认真上学，也照顾Samruay',10:'叽叽叽，咔！',11:'慢——慢——说话',13:'给Any留一份',14:'请叫我Wesley',18:'ceri mai chai 海椒，chai bandao.',19:'什么都想吃',22:'三铢帮 · 开心就唱歌',23:'三铢帮 · lunar 马辽',24:'三铢帮 · dulian ban dulian',25:'开心会晃大耳朵',27:'包下零食，和朋友一起吃',29:'听姐姐Neona的话',30:'调皮的姐姐Neona',31:'古风小生',32:'记着五个哥哥'};
Object.entries(characterTraits).forEach(([id,trait])=>mascotProfiles[id].trait=trait);

const mascotSongs={5:'this is your boy',22:'I am your muvmuv',23:'lunar is here',2:'i am polcasan'};
Object.entries(mascotSongs).forEach(([key,song])=>{let id=Number(key),c=characterStories[id];c.hello+=' 我的新歌《'+song+'》，你听过了吗？';c.thanks+=' 也要记得听听《'+song+'》哦！';c.postcard+=' 还有一首新歌《'+song+'》想推荐给你，边吃甜点边听吧！';c.second+=' 临走前，'+names[id]+'又认真介绍自己的新歌《'+song+'》，还用小勺轻轻敲了两下节拍。';Object.assign(mascotProfiles[id],{hello:c.hello,thanks:c.thanks})});

Object.entries({14:'水煮蛋（奶奶姐姐们起的外号）· 会生气',7:'荷包蛋（奶奶姐姐们起的外号）',18:'煎蛋（奶奶姐姐们起的外号）',16:'卤蛋（奶奶姐姐们起的外号）· 只说英语',13:'给Any留一份 · JASPER家',5:'20泰铢的小钱包 · JASPER家',33:'JASPER的弟弟',32:'LYKN的五个哥哥',31:'Dew家的古风小生',27:'给Tomafox留一份 · 与朋友分享',6:'爱告状的小狐狸',4:'西兰花小捣蛋'}).forEach(([id,trait])=>mascotProfiles[id].trait=trait);
function giftGreeting(gift){let c=characterStories[gift.mascot];return gift.mascot===16?'I have a little gift for you, my friend. Would you like to open it?':(gift.stage===0?c.hello:c.thanks)+' 有份小小的心意，想亲手交给你。'}

const girlMascots=[1,7,22,23,24,25,26];girlMascots.forEach(id=>mascotProfiles[id].gender='female');
