// Existing scoring and handlers are retained; their controls live on the illustrated work surface.
const drawBeforeInPicture=drawChallenge;
function pictureStage(){if(!playState.active)return Math.min(4,step);return Math.min(4,step+(selected===1?0:1))}
function integratePicture(){let scene=document.createElement('div');scene.className='interactive-scene';scene.id='interactive-scene';scene.innerHTML=foodPicture(selected,pictureStage(),'work-art')+'<div class="scene-sparkles" aria-hidden="true"></div>';board.classList.add('picture-challenge');const a=playState.active;scene.dataset.recipe=selected;scene.dataset.mode=a?.mode||'ready';board.append(scene);
let move=(selector)=>{board.querySelectorAll(selector).forEach(el=>scene.append(el))};
if(!a){let button=board.querySelector('.primary');if(button){button.classList.add('scene-start');scene.append(button)}else{scene.insertAdjacentHTML('beforeend','<div class="scene-finished">甜品做好啦 ♡</div>')}return}
move('.skill-meter,#skill-action,#skill-value,#pearl-pad,.knead,#knead-count,#swipe-pad,.craft-zone');
if(a.mode==='tap'){$('pearl-pad').innerHTML='<span class="touch-cue">点杯子 · 加珍珠</span><b id="tap-count">0 / 6</b>';scene.addEventListener('click',e=>{if(typeof recipeVariant!=='undefined'&&recipeVariant==='pudding'&&(!a.puddingAdded||a.justPlacedPudding)){a.justPlacedPudding=false;return}if(e.target.closest('#pearl-pad')){let bead=document.createElement('i');bead.className='falling-pearl';bead.style.left=(43+Math.random()*12)+'%';scene.append(bead);setTimeout(()=>bead.remove(),700)}})}
if(a.mode==='hold'){$('skill-action').textContent=selected===0?(step===1?'按住茶壶倒红茶':'按住奶壶倒牛奶'):'按住挤入夹心';scene.insertAdjacentHTML('beforeend',`<div class="cup-fill" aria-hidden="true" style="--liquid:${step===1?'#bf844e88':'#f3d9b388'}"><i id="live-fill"></i></div>`)}
if(a.mode==='timing')$('skill-action').textContent=selected===0?'轻点杯盖封杯':'轻点完成';
if(a.mode==='oven'){$('skill-action').textContent='点烤箱 · 开始烘烤';let original=$('skill-action').onclick;$('skill-action').onclick=()=>{original();if(playState.active===a)$('skill-action').textContent=a.running?'点烤箱 · 现在出炉':'点烤箱 · 开始烘烤'};scene.insertAdjacentHTML('beforeend','<div class="oven-glow" aria-hidden="true"></div>')}
if(a.mode==='swipe'){$('swipe-pad').querySelector('#swipe-tool').textContent='▰';$('swipe-pad').insertAdjacentHTML('afterbegin','<div class="cream-spread" aria-hidden="true"></div>');$('swipe-count').textContent='在蛋糕上来回抹奶油'}
if(a.mode==='jamdraw'){let svg=$('jam-path');svg.querySelector('rect')?.setAttribute('fill','transparent');$('jam-key').textContent='轻点裱花袋 · 挤一段';}
if(a.mode==='slice'){$('roll-action').textContent='沿蛋糕卷轻轻卷起 ↪';}
if(a.mode==='pipe'){scene.querySelectorAll('.piping-dot span').forEach(el=>el.textContent='按住挤在这里')}
if(a.mode==='knead'){$('left-hand').textContent='左边揉一揉';$('right-hand').textContent='右边揉一揉';}

}
drawChallenge=function(){drawBeforeInPicture();integratePicture()};
let pictureFrameLast=0;function pictureFrame(now){if(now-pictureFrameLast>50){pictureFrameLast=now;let a=playState.active,scene=$('interactive-scene');if(a&&scene){scene.style.setProperty('--work-progress',Math.min(100,a.value||a.distance/7||a.count*12||0)+'%');scene.classList.toggle('working',!!a.running);let live=$('live-fill');if(live)live.style.height=Math.min(100,a.value)+'%';}}requestAnimationFrame(pictureFrame)}requestAnimationFrame(pictureFrame);
document.querySelector('.hint').textContent='点击或拖动插画上的材料和工具，亲手完成这道甜品。';renderRecipe();
